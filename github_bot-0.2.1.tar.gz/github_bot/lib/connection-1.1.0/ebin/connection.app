{application,connection,
             [{config_mtime,1780081260},
              {optional_applications,[]},
              {applications,[kernel,stdlib,elixir]},
              {description,"Connection behaviour for connection processes\n"},
              {modules,['Elixir.Connection']},
              {registered,[]},
              {vsn,"1.1.0"}]}.
